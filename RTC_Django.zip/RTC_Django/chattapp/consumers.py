import json
from channels.generic.websocket import AsyncWebsocketConsumer, WebsocketConsumer
from asgiref.sync import sync_to_async, async_to_sync
from .models import Message


class ChatConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        self.room_name = self.scope['url_route']['kwargs']['room_name']
        self.room_group_name = 'chat_%s' % self.room_name

        # Join room
        await self.channel_layer.group_add(
            self.room_group_name,
            self.channel_name
        )
        # async_to_sync(self.channel_name.group_add)(
        #     self.room_group_name,
        #     self.channel_name
        # )

        await self.accept()

    async def disconnect(self, code):
        # Leave room
        await self.channel_layer.group_discard(
            self.room_group_name,
            self.channel_name
        )
        # async_to_sync(self.channel_layer.group_discord)(
        #     self.room_group_name,
        #     self.channel_name
        # )

    # Receive message from web socket
    async def receive(self, text_data):
        data = json.loads(text_data)
        message = data['message']
        username = data['username']
        room = data['room']

        # Send message to database by calling send_message function
        await self.save_message(username, room, message)

        # Send data back to the group or page
        await self.channel_layer.group_send(
            self.room_group_name,
            {
                'type': 'chat_message',
                'message': message,
                'username': username,
                'room': room
            }
        )

    # Receive message from room group
    async def chat_message(self, event):
        message = event['message']
        username = event['username']

        # Send message to web socket
        await self.send(text_data=json.dumps({
            'message': message,
            'username': username
        }))

    @sync_to_async()
    def save_message(self, username, room, message):
        Message.objects.create(username=username, room=room, content=message)
