from django.contrib import admin
from .models import Message


class message_view(admin.ModelAdmin):
    list_display = ("room", "username",)
    search_fields = ['room', 'username', ]


# Register your models here.
admin.site.register(Message, message_view)
